package com.capgemini.bank.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.BankException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

public class Client {

	static Scanner scan = new Scanner(System.in);
	static IDemandDraftService idemandraftService = null;
	static DemandDraftService demanddraftService = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");
		DemandDraft draftbean = null;

		String transaction_id = null;
		int opt = 0;

		while (true) {

			// Menu
			System.out.println();
			System.out.println();
			System.out.println("   XYZ Bank   ");
			System.out.println("_______________________________\n");

			System.out.println("1.Enter Demand Draft Details ");
			System.out.println("2.Print Demand Draft");
			System.out.println("3.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accepting option

			try {
				opt = scan.nextInt();

				switch (opt) {

				case 1:

					while (draftbean == null) {
						draftbean = populateDemandDraft();
					}

					try {
						demanddraftService = new DemandDraftService();
						transaction_id = demanddraftService.addDraftDetails(draftbean);

						System.out.println("Your Demand Draft request has been successfully registered along with the  " +   transaction_id);
			

					} catch (BankException BankException) {
						logger.error("exception occured", BankException);
						System.out.println("ERROR : "
								+ BankException.getMessage());
					} finally {
						transaction_id = null;
						demanddraftService = null;
						draftbean = null;
					}

					break;
					
				case 2:

					demanddraftService = new DemandDraftService();

					System.out.println("Enter numeric transaction id:");
					transaction_id = scan.next();

					while (true) {
						if (demanddraftService.validateDraftId(transaction_id)) {
							break;
						} else {
							System.err
									.println("Please enter numeric transaction id only, try again");
							transaction_id = sc.next();
						}
					}

					draftbean = getDraftDetails(transaction_id);

					if (draftbean != null) {
						System.out.println("Customer_name             :"
								+ draftbean.getCustomer_name());
						System.out.println("In_favor_of          :"
								+ draftbean.getIn_favor_of());
						System.out.println("Phone Number     :"
								+ draftbean.getPhone_number());
						System.out.println("Date_of_transaction       :"
								+ draftbean.getDate_of_transaction());
						System.out.println("Amount       :"
								+ (draftbean.getDd_amount()+draftbean.getDd_commission()));
						System.out.println("Dd_description()  :"
								+ draftbean.getDd_description());
					} else {
						System.err
								.println("There are no  details associated with transcation id "
										+ transaction_id);
					}

					break;
		
		

				case 3:

					System.out.print("Exit Bank Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option");
				}    // end of switch
			}

			catch (InputMismatchException e) {
				scan.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while
	}// end of try

	    private static DemandDraft getDraftDetails(String transaction_id) {
		DemandDraft demanddraftbean = null;
		idemandraftService = new DemandDraftService();

		try {
			demanddraftbean = idemandraftService.viewDraftDetails(transaction_id);
		} catch (BankException bankException) {
			logger.error("exception occured ", bankException);
			System.out.println("ERROR : " + bankException.getMessage());
		}

		idemandraftService = null;
		return demanddraftbean;
	}
	    
	private static DemandDraft populateDemandDraft() {

		
		DemandDraft draftbean = new DemandDraft();;

		System.out.println("\n Enter Customer Details");

		System.out.println("Enter customer name: ");
		draftbean.setCustomer_name(scan.next());

		System.out.println("In favor of: ");
		draftbean.setIn_favor_of(scan.next());

		System.out.println("Enter phone number: ");
		draftbean.setPhone_number(scan.next());
		
		System.out.println("Enter DD amount");
		draftbean.setDd_amount(scan.nextInt());
		
		System.out.println("DD Description");
		draftbean.setDd_description(scan.next());
		
		demanddraftService = new DemandDraftService();

		try {
			demanddraftService.validateDemandDraft(draftbean);
			return draftbean;
		} catch (BankException bankException) {
			logger.error("exception occured",bankException);
			System.err.println("Invalid data:");
			System.err.println(bankException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
}

