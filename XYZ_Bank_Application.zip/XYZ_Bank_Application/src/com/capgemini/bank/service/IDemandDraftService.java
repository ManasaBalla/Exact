package com.capgemini.bank.service;
import com.capemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.BankException;

public interface IDemandDraftService 
{
	public String addDraftDetails(DemandDraft demanddraftbean) throws BankException;
	public DemandDraft viewDraftDetails(String transaction_id) throws BankException;
}