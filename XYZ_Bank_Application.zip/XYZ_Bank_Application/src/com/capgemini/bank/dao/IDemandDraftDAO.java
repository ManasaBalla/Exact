package com.capgemini.bank.dao;

import com.capemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.BankException;

public interface IDemandDraftDAO 
{
	public String addDraftDetails(DemandDraft draftbean) throws BankException;
	public DemandDraft viewDraftDetails(String transaction_id) throws BankException;
	
}

